<?php
include("header.php");
?>
<div class="banner">
    <img src="banar.jpg" alt="AirWell Banner" class="banner-image">
    <h1 class="banner-text">About Us</h1>
</div>
<style>
    .banner {
        position: relative;
        width: 100%;
        height: 300px;
        overflow: hidden;
    }

    .banner-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        filter: grayscale(50%) brightness(70%);
    }

    .banner-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
        font-size: 3em;
        font-weight: bold;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }

    .content {
        max-width: 800px;
        margin: 40px auto;
        padding: 20px;
    }

    .mission,
    .vision {
        background-color: white;
        padding: 30px;
        margin-bottom: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    h2 {
        color: #2c3e50;
        font-size: 1.8em;
        margin-bottom: 20px;
        border-bottom: 2px solid #3498db;
        padding-bottom: 10px;
    }

    .highlight {
        color: #3498db;
        margin-right: 10px;
    }

    h3 {
        color: #2c3e50;
        font-size: 1.4em;
        margin-top: 30px;
    }

    p {
        text-align: justify;
        margin-bottom: 15px;
    }

    ul {
        padding-left: 20px;
    }

    li {
        margin-bottom: 10px;
    }

    strong {
        color: #2c3e50;
    }

    @media (max-width: 768px) {
        .banner-text {
            font-size: 2em;
        }

        .content {
            padding: 15px;
        }

        .mission,
        .vision {
            padding: 20px;
        }
    }
</style>
<main class="content">
    <section class="mission">
        <h2><span class="highlight">-----</span>Our Mission</h2>
        <p>Welcome to AirWell, your number one source for high-quality air conditioning solutions. We're dedicated to providing you the very best of cooling systems, with a focus on dependability, customer service, and uniqueness.</p>
    </section>

    <section class="vision">
        <h2><span class="highlight">-----</span>Our Vision</h2>
        <p>Founded in 2023, AirWell has come a long way from its beginnings in Mumbai. When we first started out, our passion for providing efficient, eco-friendly air conditioning systems drove us to start our own business.</p>

        <p>Our mission is simple: to bring comfort to your homes and workplaces with the latest and most reliable air conditioning technology. We believe that everyone deserves a cool, comfortable space, and we strive to offer top-notch products and exceptional customer service.</p>

        <h3>Why Choose Us?</h3>
        <ul>
            <li><strong>Quality Products:</strong> We offer a wide range of air conditioners from leading brands, ensuring you get the best quality and performance.</li>
            <li><strong>Expertise:</strong> Our team comprises highly trained professionals with years of experience in the HVAC industry. We provide expert advice and solutions tailored to your needs.</li>
            <li><strong>Customer Satisfaction:</strong> Your satisfaction is our top priority. We are committed to ensuring that you are completely happy with your purchase and installation.</li>
            <li><strong>Eco-Friendly Solutions:</strong> We are dedicated to promoting environmentally friendly products that help reduce energy consumption and carbon footprint.</li>
        </ul>

        <h3>Our Products</h3>
        <p>We offer a comprehensive selection of air conditioning products, including:</p>
        <ul>
            <li>Window Air Conditioners</li>
            <li>Split Air Conditioners</li>
            <li>Portable Air Conditioners</li>
            <li>Central Air Conditioning Systems</li>
            <li>Ductless Mini-Split Systems</li>
        </ul>
        <p>Each product is carefully selected to meet our high standards of efficiency, durability, and performance.</p>
    </section>
</main>
<?php
include("footer.php");
?>

</body>

</html>