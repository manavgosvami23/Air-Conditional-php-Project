<?php
session_start();
include('db.php');

if (isset($_SESSION['user_track'])) {
    $id = $_SESSION['user_track']['u_id']; 
    
    // discount update logic
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['claimed_discount'])) {
        $claimed_discount = (float)$_POST['claimed_discount']; // Discount claimed by the user
        
        // Insert or update the discount in wallet
        $update_wallet_query = "
            INSERT INTO wallet (user_id, discount) 
            VALUES ($id, $claimed_discount)
            ON DUPLICATE KEY UPDATE discount = $claimed_discount";
        mysqli_query($conn, $update_wallet_query);
    }

    $check_wallet_query = "SELECT * FROM wallet WHERE user_id = $id";
    $check_wallet_result = mysqli_query($conn, $check_wallet_query);
    
    if (mysqli_num_rows($check_wallet_result) > 0) {
        $wallet_row = mysqli_fetch_assoc($check_wallet_result);
        $discount = $wallet_row['discount'];
        $wallet_label = "Wallet: $discount";
    } else {
        $wallet_label = "Wallet: 0";
    }
} else {
    $wallet_label = "Wallet: N/A";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Online AC Shop</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"/>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet"/>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <style>
      /* Flexbox for the nav items */
      .navs ul {
        display: flex;
        align-items: center;
      }
      .navs li {
        margin: 0 10px;
      }
     
    </style>
</head>
<body>
    <header>
        <div class="main">
            <h1 class="logo">Air<span>Well</span></h1>
            <nav class="Navs">
                <ul class="mb-0">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About us</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                    <li><a href="shop.php">Shop</a></li>
                  

                  
                    <?php if (isset($_SESSION['user_track'])) { ?>
                        <li><a href="myorder.php">My Order</a></li>
                        <li><a href="logout.php" class="login">Logout</a></li>
                        <li><span class="wallet-label"><?php echo $wallet_label; ?></span></li>
                    <?php } else { ?>
                        <li><a href="login.php" class="login">Login</a></li>
                    <?php } ?>
                </ul>
            </nav>
            <div class="navs">
                <ul class="nav">
                    <?php
                    if (isset($_SESSION['user_track'])) 
                    {
                        
                        echo '<h6 style="color:white; font-size:18px;">Welcome ' . $_SESSION['user_track']['username'] . '</h6>';
                        
                        $id = $_SESSION['user_track']['u_id'];
                        $s = "SELECT * FROM cart WHERE user_id = $id";
                        $row = mysqli_query($conn, $s) or die('query failed');
                        $row_count = mysqli_num_rows($row);
                    ?>
                        <li class="nav-item" style="list-style:none;">
                            <a href="cart.php" class="nav-link" style="color:white; list-style:none;">
                                <i class="fa-solid fa-cart-shopping">
                                    <sup style="color:skyblue;"><?php echo $row_count; ?></sup>
                                </i>
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </header>
</body>
</html>
