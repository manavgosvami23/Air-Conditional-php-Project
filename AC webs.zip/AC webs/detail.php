<?php
include("db.php");
include("header.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>MultiShop - Online Shop Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    
    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Shop Detail Start -->
    <div class="container-fluid pb-5">
        <div class="row px-xl-5">
            <div class="col-lg-5 mb-30">
                <div id="product-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner bg-light">
                        <div class="carousel-item active">
                        <?php
                        $id = $_GET['id'];
                        $fetch_product = "SELECT * FROM products WHERE id='$id'";
                        $fetch_product_Ex = mysqli_query($conn, $fetch_product);
                        $data = mysqli_fetch_array($fetch_product_Ex);
                        
                        // Fetch stock
                        $stock = $data['stock'];

                        if(isset($_POST['add_to_cart'])) {
                            if(!isset($_SESSION['user_track']['u_id'])){
                                header('location:login.php');
                            }
                            $users_id = $_SESSION['user_track']['u_id'];
                            $p_id=$data['id'];
                            $cart_image = $data['image'];
                            $cart_name = $data['name'];
                            $cart_price = $data['price'];
                            $quantity = 1;
                            $cart_total = $data['price'];

                            // Check if stock is available
                            if($stock <= 0) {
                                echo "<script>alert('Out of stock');</script>";
                            } else {
                                // Check if the product is already in the cart
                                $check_cart = "SELECT * FROM cart WHERE user_id='$users_id' AND cart_name='$cart_name'";
                                $check_cart_ex = mysqli_query($conn, $check_cart);

                                if(mysqli_num_rows($check_cart_ex) > 0) {
                                    echo "<script>alert('Product already in cart');</script>";
                                } else {
                                    // Insert the product into the cart
                                    $cart_ins = "INSERT INTO cart (user_id,pro_id,cart_name, cart_image, cart_price, cart_quantity, cart_total) VALUES ('$users_id','$p_id','$cart_name', '$cart_image', '$cart_price', '$quantity', '$cart_total')";
                                    $cart_ins_ex = mysqli_query($conn, $cart_ins);

                                    if($cart_ins_ex) {
                                        echo "<script>alert('Added to cart');</script>";
                                    } else {
                                        echo "<script>alert('Something went wrong');</script>";
                                    }
                                }
                            }
                        }
                        ?>
                            <img class="w-100 h-100" src="<?php echo $data['image']; ?>" alt="Image">
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 h-auto mb-30">
                <div class="h-100 bg-light p-30">
                    <h1><?php echo $data['name']; ?></h1>
                    <div class="d-flex mb-3">
                        <div class="text-info mr-2">
                            <small class="fas fa-star"></small>
                            <small class="fas fa-star"></small>
                            <small class="fas fa-star"></small>
                            <small class="fas fa-star-half-alt"></small>
                            <small class="far fa-star"></small>
                        </div>
                    </div>
                    <h3 class="font-weight-semi-bold mb-4"><?php echo $data['price']; ?></h3>
                    <!-- <p class="mb-4"><?php echo $data['short_description']; ?></p> -->
                    
                    <!-- Show stock availability -->
                    <p class="mb-4"><?php echo $stock > 0 ? "In stock: $stock" : "Out of stock"; ?></p>

                    <div class="d-flex align-items-center mb-4 pt-2">
                        <form method="POST">
                            <button type="submit" name="add_to_cart" class="btn btn-info px-3" <?php echo $stock <= 0 ? 'disabled' : ''; ?>><i class="fa fa-shopping-cart mr-1"></i> Add To Cart</button>
                        </form>
                    </div>
                    <div class="d-flex pt-2">
                        <strong class="text-dark mr-2">Share on:</strong>
                        <div class="d-inline-flex">
                            <a class="text-dark px-2" href="">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a class="text-dark px-2" href="">
                            <i class="fa-brands fa-x-twitter"></i>
                            </a>
                            <a class="text-dark px-2" href="">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a class="text-dark px-2" href="">
                                <i class="fab fa-pinterest"></i>
                            </a>
                        </div>
                    </div><br>
                    <strong>DELAVERY DURATION:2 DAYS</strong>

                </div>
            </div>
        </div>
        <div class="row px-xl-5">
            <div class="col">
                <div class="bg-light p-30">
                    <div class="nav nav-tabs mb-4">
                        <a class="nav-item nav-link text-dark active" data-toggle="tab" href="#tab-pane-1">Description</a>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="tab-pane-1">
                            <h4 class="mb-3">Product Description</h4>
                            <p><?php echo $data['description']; ?></p> 
                        </div>
                        <div class="tab-pane fade" id="tab-pane-2">
                            <h4 class="mb-3">Additional Information</h4>
                            <p>Eos no lorem eirmod diam diam, eos elitr et gubergren diam sea. Consetetur vero aliquyam invidunt duo dolores et duo sit. Vero diam ea vero et dolore rebum, dolor rebum eirmod consetetur invidunt sed sed et, lorem duo et eos elitr, sadipscing kasd ipsum rebum diam. Dolore diam stet rebum sed tempor kasd eirmod. Takimata kasd ipsum accusam sadipscing, eos dolores sit no ut diam consetetur duo justo est, sit sanctus diam tempor aliquyam eirmod nonumy rebum dolor accusam, ipsum kasd eos consetetur at sit rebum, diam kasd invidunt tempor lorem, ipsum lorem elitr sanctus eirmod takimata dolor ea invidunt.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Detail End -->
</body>
<?php
include("footer.php");
?>
</html>
