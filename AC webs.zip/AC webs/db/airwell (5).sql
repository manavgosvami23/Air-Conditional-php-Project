-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2024 at 12:30 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airwell`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `password`) VALUES
(1, 'parth', '4033'),
(2, 'manav', '4055');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pro_id` int(100) NOT NULL,
  `cart_name` varchar(100) NOT NULL,
  `cart_image` varchar(100) NOT NULL,
  `cart_price` decimal(10,2) NOT NULL,
  `cart_quantity` varchar(100) NOT NULL,
  `cart_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `pro_id`, `cart_name`, `cart_image`, `cart_price`, `cart_quantity`, `cart_total`) VALUES
(135, 2, 3, 'LG', 'lg.jpeg', '30000.00', '2', '30000.00');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cart_id` int(11) NOT NULL,
  `pro_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile_no` varchar(20) DEFAULT NULL,
  `address_line1` varchar(255) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `check_price` varchar(150) NOT NULL,
  `check_quantity` varchar(100) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`order_id`, `user_id`, `cart_id`, `pro_id`, `first_name`, `last_name`, `email`, `mobile_no`, `address_line1`, `city`, `state`, `zip_code`, `check_price`, `check_quantity`, `order_date`, `payment_method`) VALUES
(4, 2, 106, 1, 'fsfsf', 'dfvsdfv', 'manav@gmail.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '23000.00', '1', '2024-08-31 20:39:16', 'debit card'),
(5, 2, 107, 3, 'cvnf', 'dfvsdfv', 'manav@gmail.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '30000.00', '1', '2024-08-31 20:45:13', 'debit card'),
(6, 2, 108, 3, 'assdfcwdc', 'sdcsd', 'dcvd@gmail.com', '4568956825', 'asas', 'erfgefg', 'sadcsd', '123456', '30000.00', '2', '2024-08-31 21:09:20', 'debit card'),
(7, 2, 109, 4, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-08-31 22:12:14', 'debit card'),
(8, 2, 112, 3, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '30000.00', '1', '2024-08-31 22:27:28', 'banktransfer'),
(9, 2, 114, 4, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-08-31 22:27:28', 'banktransfer'),
(10, 2, 115, 1, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '23000.00', '1', '2024-08-31 22:27:28', 'banktransfer'),
(11, 2, 116, 4, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-08-31 22:31:34', 'debit card'),
(12, 2, 117, 1, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '23000.00', '1', '2024-08-31 22:31:34', 'debit card'),
(13, 2, 118, 3, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '30000.00', '1', '2024-08-31 22:31:34', 'debit card'),
(14, 2, 124, 4, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-09-02 19:18:55', 'credit card'),
(15, 2, 125, 4, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '2', '2024-09-02 19:29:31', 'debit card'),
(16, 2, 126, 4, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-09-02 20:01:08', 'banktransfer'),
(17, 2, 127, 3, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '30000.00', '1', '2024-09-02 20:02:22', 'debit card'),
(18, 2, 128, 3, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '30000.00', '1', '2024-09-02 20:03:20', 'debit card'),
(19, 2, 129, 4, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-09-02 20:06:18', 'debit card'),
(20, 2, 130, 4, 'cvnf', 'dfvsdfv', 'manav@gmail.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-09-02 21:22:19', 'debit card'),
(21, 2, 131, 4, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-09-02 21:33:33', 'debit card'),
(22, 2, 132, 4, 'cvnf', 'sfdsds', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '40000.00', '1', '2024-09-02 21:55:27', 'debit card'),
(23, 2, 133, 3, 'cvnf', 'dfvsdfv', 'manav@gmail.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '30000.00', '1', '2024-09-02 22:00:03', 'debit card'),
(24, 3, 136, 3, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '30000.00', '1', '2024-09-03 22:16:01', 'debit card'),
(25, 3, 137, 3, 'cvnf', 'dfvsdfv', 'manav@123.com', '4651616556', 'dbgdsgfb', 'fdbfcvb', 'fsbsfgbsfgb', '567567', '30000.00', '1', '2024-09-03 22:26:00', 'credit card');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `invoice_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `shipping_amount` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `address_line1` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip_code` varchar(6) NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_id`, `user_id`, `invoice_date`, `total_amount`, `shipping_amount`, `subtotal`, `first_name`, `mobile_no`, `address_line1`, `city`, `state`, `zip_code`, `payment_method`, `quantity`) VALUES
(1, 3, '2024-09-03 22:24:07', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(2, 3, '2024-09-03 22:24:07', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(3, 3, '2024-09-03 22:24:16', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(4, 3, '2024-09-03 22:24:48', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(5, 3, '2024-09-03 22:25:36', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(6, 3, '2024-09-03 22:25:36', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(7, 3, '2024-09-03 22:25:36', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(8, 3, '2024-09-03 22:25:36', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(9, 3, '2024-09-03 22:26:18', '23000.00', '1000.00', '23000.00', ' fsfsf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(10, 3, '2024-09-03 22:27:34', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(11, 3, '2024-09-03 22:27:34', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(12, 3, '2024-09-03 22:27:34', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(13, 3, '2024-09-03 22:28:02', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(14, 3, '2024-09-03 22:28:28', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(15, 3, '2024-09-03 22:28:28', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(16, 3, '2024-09-03 22:28:28', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(17, 3, '2024-09-03 22:28:55', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1),
(18, 3, '2024-09-03 22:28:56', '30000.00', '1000.00', '30000.00', ' cvnf', '4651616556', ' dbgdsgfb', ' fdbfcvb', ' fsbsfgbsfgb', ' 56756', ' debit card', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `brand`, `price`, `stock`, `image`, `description`) VALUES
(1, 'PANASONIC', 'PANASONIC', '23000.00', -1, 'blue star.jpeg', 'tjis '),
(3, 'LG', 'LG', '30000.00', 3, 'lg.jpeg', NULL),
(4, 'blue star', 'blue star', '40000.00', -11, 'blue star.jpeg', 'this is amazing product');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `u_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`u_id`, `firstname`, `lastname`, `username`, `email`, `password`) VALUES
(1, 'parth', 'devaliya', 'gajjar', 'parth@gmail.com', '1210'),
(2, 'manav', 'manav', 'manav', 'manav@gmail.com', '4055'),
(3, 'kandarp', 'agravat', '@kandarp', 'ak@gmail.com', '123'),
(4, 'kjhbk', 'bjdb', 'jkdcnjk', 'manav@gmail.com', '452345687'),
(5, 'abhishek', 'maheta', 'abhishek', 'abhishek@gmail.com', '9426114979');

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wallet`
--

INSERT INTO `wallet` (`id`, `user_id`, `discount`, `created_at`, `updated_at`) VALUES
(1, 2, '30950', '2024-08-31 22:31:40', '2024-09-02 22:00:12'),
(2, 3, '3100', '2024-09-03 22:16:08', '2024-09-03 22:26:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `pro_id` (`pro_id`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `cart_id` (`cart_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wallet`
--
ALTER TABLE `wallet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `register` (`u_id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`pro_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `register` (`u_id`);

--
-- Constraints for table `wallet`
--
ALTER TABLE `wallet`
  ADD CONSTRAINT `wallet_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `register` (`u_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
