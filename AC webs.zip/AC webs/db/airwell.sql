-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2024 at 11:03 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airwell`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `password`) VALUES
(1, 'parth', '4033'),
(2, 'manav', '4055');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pro_id` int(100) NOT NULL,
  `cart_name` varchar(100) NOT NULL,
  `cart_image` varchar(100) NOT NULL,
  `cart_price` decimal(10,2) NOT NULL,
  `cart_quantity` varchar(100) NOT NULL,
  `cart_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cart_id` int(11) NOT NULL,
  `pro_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile_no` varchar(20) DEFAULT NULL,
  `address_line1` varchar(255) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `check_price` varchar(150) NOT NULL,
  `check_quantity` varchar(100) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(11) NOT NULL,
  `u_id` int(100) NOT NULL,
  `u_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_id`, `u_id`, `u_name`, `email`, `subject`, `message`) VALUES
(1, 2, 'manav', 'manav@gmail.com', 'products reviews', 'your all products are best Thank you for giving us best products and services.'),
(2, 1, 'parth', 'parth@gmail.com', 'UI', '\"Experience ultimate comfort with our range of energy-efficient air conditioners. Designed for performance and quiet operation, our models cater to every space and budget. Explore features like smart '),
(3, 3, 'kandrap', 'kandrap@gmail.com', 'discount ', 'your Spinner discount concept is very best  Thank you for giving us discount on products.');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `brand`, `price`, `stock`, `image`, `description`) VALUES
(5, 'Blue Star 1.5 Ton 5 Star Inverter Split AC', 'Blue Star', '39315.00', 35, 'blue star.jpeg', 'Experience superior cooling with the Blue Star 1.5 Ton 5 Star Inverter Split AC, designed to deliver optimal comfort and energy efficiency. This air conditioner features advanced inverter technology, ensuring consistent cooling while reducing power consumption, making it both eco-friendly and cost-effective.'),
(6, 'Carrier 1.5 Ton 5 Star AI Flexicool Inverter Split AC', 'Carrier', '45090.00', 26, 'carrier.jpeg', 'Elevate your cooling experience with the Carrier 1.5 Ton 5 Star AI Flexicool Inverter Split AC, engineered for superior performance and maximum energy efficiency. This air conditioner is equipped with AI Flexicool technology, allowing it to intelligently adjust cooling based on your preferences and ambient conditions, ensuring personalized comfort.'),
(7, 'Godrej 1.5 Ton 5 Star, 5-In-1 Convertible Cooling, Inverter Split AC', 'Godrej', '39735.00', 33, 'gothareg.jpeg', 'Stay cool and comfortable with the Godrej 1.5 Ton 5 Star, 5-In-1 Convertible Cooling, Inverter Split AC. This advanced air conditioner is designed to deliver flexible cooling options and unmatched energy efficiency, making it a perfect choice for modern homes. The 5-in-1 Convertible Cooling feature allows you to adjust cooling modes based on your needs, ensuring optimal comfort and energy savings.'),
(8, 'Voltas 1.5 ton 5 Star Inverter Split AC', 'Voltas', '45090.00', 50, 'voltas.jpeg', 'Stay cool and comfortable with the Voltas 1.5 Ton 5 Star Inverter Split AC, designed to deliver powerful performance and excellent energy efficiency. This air conditioner is equipped with advanced inverter technology that adjusts the compressor speed according to room temperature, ensuring consistent cooling while saving energy.'),
(9, 'Lloyd 1.5 Ton 5 Star Inverter Split AC', 'Lloyd', '51399.00', 48, 'lloyd.png', 'Experience efficient and reliable cooling with the Lloyd 1.5 Ton 5 Star Inverter Split AC, designed to provide superior comfort while minimizing energy consumption. This air conditioner features advanced inverter technology that ensures optimal cooling performance with reduced power usage, making it a smart choice for your home.'),
(11, 'Samsung 1.5 Ton 5 Star 2024 Model, Inverter Split AC, White', 'Samsung', '42990.00', 50, 'samsung.jpeg', 'The Samsung 1.5 Ton 5 Star 2024 Inverter Split AC delivers efficient cooling with a sleek design and smart features. Enjoy quieter operation and cleaner air, all while saving on energy bills!'),
(12, 'LG 1.5 Ton 5 Star DUAL Inverter Split AC ', 'LG', '48765.00', 50, 'lg.jpeg', 'The LG 1.5 Ton 5 Star DUAL Inverter Split AC offers rapid cooling and exceptional energy efficiency with advanced DUAL Inverter technology. Enjoy cleaner air and smart connectivity for ultimate convenience in your home!'),
(13, 'Whirlpool 1.5 Ton 5 Star, Flexicool Inverter Split AC ', 'Whirlpool ', '41900.00', 50, 'wp.jpeg', 'The Whirlpool 1.5 Ton 5 Star Flexicool Inverter Split AC provides efficient cooling and customizable comfort with its unique Flexicool technology. Enjoy energy savings and a smart design that adapts to your cooling needs seamlessly!\r\n\r\n\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `u_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`u_id`, `firstname`, `lastname`, `username`, `email`, `password`) VALUES
(1, 'parth', 'devaliya', 'gajjar', 'parth@gmail.com', '1210'),
(2, 'manav', 'manav', 'manav', 'manav@gmail.com', '4055'),
(3, 'kandarp', 'agravat', '@kandarp', 'ak@gmail.com', '123'),
(4, 'kjhbk', 'bjdb', 'jkdcnjk', 'manav@gmail.com', '452345687'),
(5, 'abhishek', 'maheta', 'abhishek', 'abhishek@gmail.com', '9426114979');

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wallet`
--

INSERT INTO `wallet` (`id`, `user_id`, `discount`, `created_at`, `updated_at`) VALUES
(1, 1, '24168.6', '2024-09-05 04:06:45', '2024-10-03 07:42:54'),
(2, 2, '156750.21', '2024-09-10 06:55:32', '2024-09-28 21:54:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `pro_id` (`pro_id`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `cart_id` (`cart_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `u_id` (`u_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wallet`
--
ALTER TABLE `wallet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `register` (`u_id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`pro_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `register` (`u_id`);

--
-- Constraints for table `wallet`
--
ALTER TABLE `wallet`
  ADD CONSTRAINT `wallet_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `register` (`u_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
