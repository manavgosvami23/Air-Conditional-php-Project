<?php
include('db.php');
session_start();
if (!isset($_SESSION['admin_track'])) {
    header("location:login.php");
    exit();
}

// order cancel
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];

    $delete_order = "DELETE FROM checkout WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $delete_order);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $order_id);
        $executed = mysqli_stmt_execute($stmt);

        if ($executed) {
            $message = "Order Cancelled Successfully";
        } else {
            $message = "Error deleting order: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
    } else {
        $message = "Error preparing statement: " . mysqli_error($conn);
    }
}

$fetch_orders = "SELECT * FROM checkout ORDER BY order_id"; // Adjust the column name if necessary
$orders = mysqli_query($conn, $fetch_orders);

if (!$orders) {
    die("Error fetching orders: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - Admin Panel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background-color: #f4f4f4;
        }

        .container {
            display: flex;
            width: 100%;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
        }

        .sidebar h2 {
            margin-bottom: 30px;
        }

        .sidebar nav ul {
            list-style: none;
        }

        .sidebar nav ul li {
            margin-bottom: 10px;
        }

        .sidebar nav ul li a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar nav ul li a:hover {
            background-color: #34495e;
        }

        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #fff;
        }

        .main-content header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .main-content header h1 {
            font-size: 24px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        button {
            padding: 5px 10px;
            background-color: red;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background-color: darkred;
        }

        .message {
            margin-bottom: 20px;
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <ul>
                    <li><a href="admin.php">Dashboard</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="orders.php">Orders</a></li>
                    <li><a href="manage_users.php">Users</a></li>
                    <li><a href="sales.php">Sales</a></li>
                    <li><a href="feedback.php">FeedBack</a></li>

                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <header>
                <h1>Orders</h1>
            </header>
            <?php if (isset($message)): ?>
                <p class="message"><?php echo htmlspecialchars($message); ?></p>
            <?php endif; ?>
            <section class="orders">
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>User ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Mobile No</th>
                            <th>Address</th>
                            <th>City</th>
                            <th>State</th>
                            <th>ZIP Code</th>
                            <th>Payment Method</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($orders) > 0) {
                            while ($order = mysqli_fetch_assoc($orders)) {
                                echo "<tr>
                                    <td>" . htmlspecialchars($order['order_id']) . "</td>
                                    <td>" . htmlspecialchars($order['user_id']) . "</td>
                                    <td>" . htmlspecialchars($order['first_name']) . "</td>
                                    <td>" . htmlspecialchars($order['last_name']) . "</td>
                                    <td>" . htmlspecialchars($order['email']) . "</td>
                                    <td>" . htmlspecialchars($order['mobile_no']) . "</td>
                                    <td>" . htmlspecialchars($order['address_line1']) . "</td>
                                    <td>" . htmlspecialchars($order['city']) . "</td>
                                    <td>" . htmlspecialchars($order['state']) . "</td>
                                    <td>" . htmlspecialchars($order['zip_code']) . "</td>
                                    <td>" . htmlspecialchars($order['payment_method']) . "</td>
                                    <td>
                                        <form method='post'>
                                            <input type='hidden' name='order_id' value='" . htmlspecialchars($order['order_id']) . "'>
                                            <button type='submit'>Cancel Order</button>
                                        </form>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='12'>No orders found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>
</body>
</html>
