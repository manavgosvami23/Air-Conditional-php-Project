
<?php
    session_start();
    include('db.php');

    if($_SERVER['REQUEST_METHOD']=="POST")
    {
    $user=$_POST['user'];
    $ps=$_POST['pass'];

    if(!empty($user) && !empty($ps))
    {
        $q="SELECT * FROM admin WHERE admin_name='$user' AND password='".$ps."'";
        $result=mysqli_query($conn,$q);

        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $userdata=mysqli_fetch_array($result);
                session_start();
                $_SESSION['admin_track'] = $userdata;
                header("location:admin.php");
            }else{
                echo "<script> alert('wrong username and password'); </script>";
            }
        }
        else{
        echo "<script> alert('please fill the filed'); </script>";
        }
    }
 }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="login.css">

    <title>Admin Login Page</title>
</head>
<body>
    <div class="wrapper">
        <form action="" method="post">
            <h1>Admin Login</h1>
            <div class="input">
                <input type="text" placeholder="admin name" name="user" required>
            </div>
            <div class="input">
                <input type="password" placeholder="password" name="pass" required>
            </div>
            <div class="forget">
               <label><input type="checkbox">Remember me</label>
               <a href="#">Forget password</a>
            </div>
            <button type="submit" class="btn" name="sub">Login</button>
           
        </form>
    </div>
</body>
</html>