    <?php
    include('db.php');
    session_start();
    if (!isset($_SESSION['admin_track'])) {
        header("location:login.php");
        exit();
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" 
        integrity="sha384-FyOeMGDoIr2VBp43eMD3LmK8P0cVJ1z5z9KEB4A56vLbxDD4cFZCdeVzJ51ehMZz" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"/>

        <title>Admin Panel - Air Conditioner Shop</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: Arial, sans-serif;
            }

            body {
                display: flex;
                height:100vh;
                background-color: #f4f4f4;
            }

            .container {
                display: flex;
                width: 100%;
                height:auto;
            }

            .sidebar {
                width: 250px;
                background-color: #2c3e50;
                color: #ecf0f1;
                padding: 20px;
            }

            .sidebar h2 {
                margin-bottom: 30px;
            }

            .sidebar nav ul {
                list-style: none;
            }

            .sidebar nav ul li {
                margin-bottom: 10px;
            }

            .sidebar nav ul li a {
                color: #ecf0f1;
                text-decoration: none;
                display: block;
                padding: 10px;
                border-radius: 5px;
                transition: background 0.3s;
            }

            .sidebar nav ul li a:hover {
                background-color: #34495e;
            }

            .main-content {
                flex-grow: 1;
                padding: 20px;
                background-color: #fff;
            }

            .main-content header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            }

            .main-content header h1 {
                font-size: 24px;
            }

            .main-content header button {
                padding: 10px 20px;
                background-color: blue;
                color: #fff;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                transition: background 0.3s;
            }

            .main-content header button:hover {
                background-color: #2980b9;
            }

            .main-content header .icon {
                margin-left: 10px;
                font-size: 24px;
                color: #2c3e50;
            }
        .pro{
                position: absolute;
                top:22%;
                font-size:6rem;
                left:30%;
                border:3px solid black;
                width: 25%;
                padding:0 1%;
                border-radius:10px;
                box-shadow:0px 0px 10px #e74e4e;
                background:#e74e4e;
        }
        .order{
                position: absolute;
                top:22%;
                font-size:6rem;
                left:50%;
                border:3px solid black;
                width: 25%;
                margin:0 10%;  
                padding:0 1%;
                border-radius:10px;
                box-shadow:0px 0px 10px #5151e2;
                background:#5151e2;
        }
        .user{
                position: absolute;
                top:63%;
                font-size:6rem;
                left:30%;
                border:3px solid black;
                width:25%;
                border-radius:10px;
                padding:0 1%;
                box-shadow:0px 0px 10px #3fc47e;
                background:#3fc47e;
        }
        .sale{
                position: absolute;
                top:63%;
                font-size:6rem;
                left:50%;
                border:3px solid black;
                width: 25%;
                margin:0 10%;
                padding:0.4% 1%;
                border-radius:10px; 
                box-shadow:0px 0px 10px #d7d743;
                background:#d7d743;
        }
        .msg{
                position: absolute;
                top:42.5%;
                font-size:6rem;
                left:35%;
                border:3px solid black;
                width: 25%;
                margin:0 10%;
                padding:0 1%;
                border-radius:10px; 
                box-shadow:0px 0px 10px #259caf;
                background:#259caf;
        }
        .pro:hover, .order:hover, .user:hover, .sale:hover, .msg:hover {
                transform:translateY(-10px) scale(1.1);
                transition:all 0.5s ease-in;
                border-color:#2c3e50;
                background:none;
        }
        </style> 
    </head>
    <body>
        <div class="container">
            <aside class="sidebar">
                <h2>Admin Panel</h2>
                <nav>
                    <ul>
                        <li><a href="admin.php">Dashboard</a></li>
                        <li><a href="products.php">Products</a></li>
                        <li><a href="orders.php">Orders</a></li>
                        <li><a href="manage_users.php">Users</a></li>
                        <li><a href="sales.php">Sales</a></li>
                        <li><a href="feedback.php">FeedBack</a></li>

                        <?php
                            if (isset($_SESSION['admin_track']['admin_id'])) {
                                ?>
                                <li><a href="logout.php">Logout</a></li>
                                <?php
                            }
                        ?>
                    </ul>
                </nav>
            </aside>
            <main class="main-content">
                <header>
                    <h1 style="margin-left:28%; font-size:50px; color:#2c3e50; letter-spacing:2px; border-bottom:3px solid #2c3e50;">AIRWELL DASHBOARD</h1>
                </header>
                <section class="products">
                    <!-- Additional content can go here -->
                </section>
            </main>
        </div>

        <?php 
            $p_count = mysqli_query($conn,"SELECT * FROM products");
            $p_count_ex = mysqli_num_rows($p_count);    
            
            $o_count = mysqli_query($conn,"SELECT * FROM checkout");
            $o_count_ex = mysqli_num_rows($o_count); 

            $c_count = mysqli_query($conn,"SELECT * FROM register");
            $c_count_ex = mysqli_num_rows($c_count); 

            $f_count = mysqli_query($conn,"SELECT * FROM feedback");
            $f_count_ex = mysqli_num_rows($f_count);
            //Total Sales Sum
            $total_sales_query = mysqli_query($conn, "SELECT SUM(check_price) AS total_sales FROM checkout");
            $total_sales_data = mysqli_fetch_assoc($total_sales_query);
            $total_sales = $total_sales_data['total_sales'] ?? 0; 
            $t="";
            if($total_sales >= 10000){
                    $t="K";
            }
           if($total_sales >= 100000){
                $t="L";
           }
           if($total_sales >= 10000000){
                $t="Cr";
           }
        ?>

        <div class="icon">
            <div class="pro"><i class="fa-brands fa-product-hunt" style="color:#2c3e50;"><sup style="color:skyblue;"><?php echo $p_count_ex; ?></sup></i>  </div>
            <div class="order"><i class="fa-solid fa-clipboard-list" style="color:#2c3e50;"><sup style="color:skyblue;"><?php echo $o_count_ex; ?></sup></i>  </div>
                <div class="user"><i class="fa-solid fa-user" style="color:#2c3e50;"><sup style="color:skyblue;"><?php echo $c_count_ex; ?></sup></i>  </div>
                <div class="sale"><i class="fa-solid fa-money-check" style="color:#2c3e50;"></i><p style="color:blue; font-size:1.8rem; position:absolute; top:35%; right:15%;">₹<?php echo number_format($total_sales, 2).$t; ?></p></div>
                <div class="msg"><i class="fa-solid fa-comments" style="color:#2c3e50;"></i><sup style="color:skyblue;"><?php echo $f_count_ex; ?></sup></div>
        </div>
    </body>
    </html>  
