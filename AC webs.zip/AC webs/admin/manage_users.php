<?php
include('db.php');
session_start();

if (!isset($_SESSION['admin_track'])) {
    header("location:login.php");
    exit();
}

// user delete 
if (isset($_GET['delete_id'])) {
    $user_id = $_GET['delete_id'];
    $sql = "DELETE FROM register WHERE u_id='$user_id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('User deleted successfully');window.location='manage_users.php';</script>";
    } else {
        echo "<script>alert('Error deleting user: " . $conn->error . "');window.location='manage_users.php';</script>";
    }
    exit();
}

$sql = "SELECT * FROM register";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin Panel</title>
    <style>
       body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex; /* Enable flexbox to allow sidebar and content side by side */
}

.container {
    display: flex;
    width: 100%;
}

.sidebar {
    position: fixed; /* Make the sidebar fixed */
    top: 0;
    left: 0;
    width: 250px;
    height: 100%; /* Full height of the page */
    background-color: #2c3e50;
    color: #ecf0f1;
    padding: 20px;
    box-sizing: border-box; /* Include padding in the width/height */
}

.main-content {
    margin-left: 250px; /* Leave space for the sidebar */
    padding: 20px;
    background-color: #fff;
    flex-grow: 1;
    height: 100vh; /* Full height of the viewport */
    overflow-y: auto; /* Enable vertical scrolling */
}

.sidebar h2 {
    margin-bottom: 30px;
}

.sidebar nav ul {
    list-style: none;
    padding-left: 0;
}

.sidebar nav ul li {
    margin-bottom: 10px;
}

.sidebar nav ul li a {
    color: #ecf0f1;
    text-decoration: none;
    display: block;
    padding: 10px;
    border-radius: 5px;
    transition: background 0.3s;
}

.sidebar nav ul li a:hover {
    background-color: #34495e;
}

h1 {
    text-align: center;
    margin-top: 20px;
}

table {
    width: 100%;
    margin-top: 20px;
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #2c3e50;
    color: white;
}

a.btn {
    display: inline-block;
    padding: 5px 10px;
    margin-right: 5px;
    color: white;
    background-color: #3498db;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

a.btn:hover {
    background-color: #2980b9;
}

    </style>
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <ul>
                    <li><a href="admin.php">Dashboard</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="orders.php">Orders</a></li>
                    <li><a href="manage_users.php">Users</a></li>
                    <li><a href="sales.php">Sales</a></li>
                    <li><a href="feedback.php">FeedBack</a></li>

                    <?php if(isset($_SESSION['admin_track']['admin_id'])): ?>
                        <li><a href="logout.php">Logout</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <h1 style="text-align:left;">Manage Users</h1>

            <!-- User List -->
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['u_id']; ?></td>
                                <td><?php echo $row['firstname']; ?></td>
                                <td><?php echo $row['lastname']; ?></td>
                                <td><?php echo $row['username']; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td>
                                    <a href="manage_users.php?delete_id=<?php echo $row['u_id']; ?>" class="btn" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6">No users found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </main>
    </div>
</body>
</html>

<?php
$conn->close();
?>
