<?php
include('db.php');
session_start();
if (!isset($_SESSION['admin_track'])) {
    header("location:login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management - Air Conditioner Shop</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background-color: #f4f4f4;
        }

        .container {
            display: flex;
            width: 100%;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
        }

        .sidebar h2 {
            margin-bottom: 30px;
        }

        .sidebar nav ul {
            list-style: none;
        }

        .sidebar nav ul li {
            margin-bottom: 10px;
        }

        .sidebar nav ul li a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar nav ul li a:hover {
            background-color: #34495e;
        }

        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #fff;
        }

        .main-content header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .main-content header h1 {
            font-size: 24px;
        }

        .main-content header button {
            padding: 10px 20px;
            background-color: blue;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .main-content header button:hover {
            background-color: #2980b9;
        }

        .products table {
            width: 100%;
            border-collapse: collapse;
        }

        .products table th,
        .products table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .products table th {
            background-color: #2c3e50;
            color: #fff;
        }

        .products table td button {
            padding: 5px 10px;
            margin: 0 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .products table td button:first-child {
            background-color: #27ae60;
            color: #fff;
        }

        .products table td button:first-child:hover {
            background-color: #2ecc71;
        }

        .products table td button:last-child {
            background-color: #e74c3c;
            color: #fff;
        }

        .products table td button:last-child:hover {
            background-color: #c0392b;
        }

        .add-product-form,
        .edit-product-form {
            margin-bottom: 20px;
        }

        .add-product-form input,
        .edit-product-form input,
        .add-product-form select,
        .edit-product-form select,
        .add-product-form textarea,
        .edit-product-form textarea {
            display: block;
            margin-bottom: 10px;
            padding: 10px;
            width: 100%;
        }

        .add-product-form button,
        .edit-product-form button {
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .add-product-form button:hover,
        .edit-product-form button:hover {
            background-color: #2980b9;
        }

        .edit-product-form {
            display: none;
        }
    </style>
    <script>
        function editProduct(productId, productName, productBrand, productPrice, productStock, productDescription, productImage) {
            document.getElementById('edit-product-id').value = productId;
            document.getElementById('edit-product-name').value = productName;
            document.getElementById('edit-product-brand').value = productBrand;
            document.getElementById('edit-product-price').value = productPrice;
            document.getElementById('edit-product-stock').value = productStock;
            document.getElementById('edit-product-description').value = productDescription;
            document.getElementById('edit-product-form').style.display = 'block';
            document.getElementById('edit-product-image').value = '';
        }

        function hideEditForm() {
            document.getElementById('edit-product-form').style.display = 'none';
        }
    </script>
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <nav>
                <ul>
                    <li><a href="admin.php">Dashboard</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="orders.php">Orders</a></li>
                    <li><a href="manage_users.php">Users</a></li>
                    <li><a href="sales.php">Sales</a></li>
                    <li><a href="feedback.php">FeedBack</a></li>

                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <header>
                <h1>Product Management</h1>
                <button onclick="document.getElementById('add-product-form').style.display='block'">Add Product</button>
            </header>
            <section class="products">
                <div id="add-product-form" class="add-product-form" style="display:none;">
                    <form action="products.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="product_name" placeholder="Product Name" required>
                        <input type="text" name="product_brand" placeholder="Brand" required>
                        <input type="number" name="product_price" placeholder="Price" required>
                        <input type="number" name="product_stock" placeholder="Stock" required>
                        <textarea name="product_description" placeholder="Description" required></textarea>
                        <input type="file" name="product_image" accept="image/*" required>
                        <button type="submit" name="add_product">Add Product</button>
                    </form>
                </div>
                
                <?php
                // Add Product
                if (isset($_POST['add_product'])) {
                    $product_name = $_POST['product_name'];
                    $product_brand = $_POST['product_brand'];
                    $product_price = $_POST['product_price'];
                    $product_stock = $_POST['product_stock'];
                    $product_description = $_POST['product_description'];
                    $product_image = $_FILES['product_image']['name'];
                    $target_dir = "uploads/";
                    $target_file = $target_dir . basename($_FILES["product_image"]["name"]);

                    if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
                        $sql = "INSERT INTO products (name, brand, price, stock, description, image) VALUES ('$product_name', '$product_brand', '$product_price', '$product_stock', '$product_description', '$product_image')";

                        if ($conn->query($sql) === TRUE) {
                            echo "New product added successfully";
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                }

                // Update Product
                if (isset($_POST['update_product'])) {
                    $product_id = $_POST['product_id'];
                    $product_name = $_POST['product_name'];
                    $product_brand = $_POST['product_brand'];
                    $product_price = $_POST['product_price'];
                    $product_stock = $_POST['product_stock'];
                    $product_description = $_POST['product_description'];
                    $product_image = $_FILES['product_image']['name'];
                    $target_dir = "uploads/";
                    $target_file = $target_dir . basename($_FILES["product_image"]["name"]);

                    if ($product_image) {
                        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
                            $sql = "UPDATE products SET name='$product_name', brand='$product_brand', price='$product_price', stock='$product_stock', description='$product_description', image='$product_image' WHERE id='$product_id'";
                        } else {
                            echo "Sorry, there was an error uploading your file.";
                        }
                    } else {
                        $sql = "UPDATE products SET name='$product_name', brand='$product_brand', price='$product_price', stock='$product_stock', description='$product_description' WHERE id='$product_id'";
                    }

                    if ($conn->query($sql) === TRUE) {
                        echo "Product updated successfully";
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                }

                // Delete Product
                if (isset($_POST['delete_product'])) {
                    $product_id = $_POST['product_id'];
                    $sql = "DELETE FROM products WHERE id='$product_id'";
                    if ($conn->query($sql) === TRUE) {
                        echo "Product deleted successfully";
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                }

                // Fetch Products
                $sql = "SELECT * FROM products";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    echo '<table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Brand</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>';
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>" . $row["id"]. "</td>
                            <td>" . $row["name"]. "</td>
                            <td>" . $row["brand"]. "</td>
                            <td>" . $row["price"]. "</td>
                            <td>" . $row["stock"]. "</td>
                            <td>" . $row["description"]. "</td>
                            <td><img src='uploads/" . $row["image"]. "' width='50' height='50'></td>
                            <td>
                                <button onclick=\"editProduct('" . $row['id'] . "', '" . htmlspecialchars($row['name'], ENT_QUOTES) . "', '" . htmlspecialchars($row['brand'], ENT_QUOTES) . "', '" . $row['price'] . "', '" . $row['stock'] . "', '" . htmlspecialchars($row['description'], ENT_QUOTES) . "', '" . htmlspecialchars($row['image'], ENT_QUOTES) . "')\">Edit</button>
                                <form action='products.php' method='post' style='display:inline;'>
                                    <input type='hidden' name='product_id' value='" . $row['id'] . "'>
                                    <button type='submit' name='delete_product' onclick='return confirm(\"Are you sure you want to delete this product?\")'>Delete</button>
                                </form>
                            </td>
                        </tr>";
                    }
                    echo '</tbody>
                    </table>';
                } else {
                    echo "<tr><td colspan='8'>No products found</td></tr>";
                }

                $conn->close();
                ?>
                
                <!-- Edit Product Form -->
                <div id="edit-product-form" class="edit-product-form">
                    <form action="products.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" id="edit-product-id" name="product_id">
                        <input type="text" id="edit-product-name" name="product_name" placeholder="Product Name" required>
                        <input type="text" id="edit-product-brand" name="product_brand" placeholder="Brand" required>
                        <input type="number" id="edit-product-price" name="product_price" placeholder="Price" required>
                        <input type="number" id="edit-product-stock" name="product_stock" placeholder="Stock" required>
                        <textarea id="edit-product-description" name="product_description" placeholder="Description" required></textarea>
                        <input type="file" id="edit-product-image" name="product_image" accept="image/*">
                        <button type="submit" name="update_product">Update Product</button>
                        <button type="button" onclick="hideEditForm()">Cancel</button>
                    </form>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
