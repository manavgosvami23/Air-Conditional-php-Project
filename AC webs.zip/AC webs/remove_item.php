<?php
include("db.php");

if (isset($_POST['del_ids'])) {
    $cart_id = intval($_POST['del_ids']);

    $delete_query = "DELETE FROM cart WHERE cart_id='$cart_id'";
    $delete_result = mysqli_query($conn, $delete_query);
    if ($delete_result) {
        echo "Item removed successfully";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
