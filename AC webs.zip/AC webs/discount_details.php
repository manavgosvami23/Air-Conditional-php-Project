<?php

include("header.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discount Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            text-align: center; /* Center-aligns text and inline elements */
            /* background-color:linear-gradient(-45deg,skyblue,gray,skyblue,gray); */
            background: skyblue;
        }
        .container {
            display: flex;
            flex-direction: column; /* Stack elements vertically */
            align-items: center; /* Center items horizontally */
            width: 100%; /* Ensure the container takes full width */
            box-sizing: border-box; /* Include padding and border in the element's total width */
        }
        .image-container {
            display: flex;
            justify-content: center; /* Center the image horizontally */
            width: 100%;
            margin-bottom: 20px; /* Space between image and content */
        }
        .image-container img {
            max-width: 100%;
            height: auto;
            border-radius: 100rem;
            
        }
        .discount-info {
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            width: 100%; /* Ensure the content div takes full width of its container */
            max-width: 800px; /* Limits the width of the content block */
            box-sizing: border-box; /* Include padding and border in the element's total width */
        }
        .discount-info h2 {
            margin-top: 0;
        }
        /* Responsive design */
        @media (max-width: 768px) {
            body {
                margin: 10px;
            }
            .discount-info {
                padding: 15px;
            }
        }
        @media (max-width: 480px) {
            .discount-info {
                padding: 10px;
                font-size: 14px; /* Adjust font size for smaller screens */
            }
            .discount-info h2 {
                font-size: 18px; /* Adjust heading size for smaller screens */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="image-container">
            <img src="spinner2.png" alt="Discount Image">
        </div>
        <div class="discount-info">
            <h2>Get Guaranteed Discounts on Our AC Products!</h2>
            <p>You can receive a guaranteed discount of 5% up to 50% on our products. When you purchase one of our AC products, you'll have the chance to maximize your discount.</p>
            <p>After completing your payment, a <strong>"Claim Reward"</strong> button will appear. Clicking this button will show a spinner; click the <strong>"Spin"</strong> button to spin the wheel and determine your discount amount.</p>
            <p>The discount you win will be stored in your wallet, which you can use for future purchases. During your next purchase, the wallet balance will automatically be applied to reduce the total cost of the new product.</p>
            <p>Additionally, you can claim another spin after using your wallet balance, giving you another opportunity to win more discounts.</p>
        </div>
    </div>
</body>
</html>
<?php

include("footer.php");
?>