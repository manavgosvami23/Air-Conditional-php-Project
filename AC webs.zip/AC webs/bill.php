<?php
include('db.php');
session_start();

$uu_id = $_SESSION['user_track']['u_id'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        .invoice-container {
            width: 90%;
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .invoice-header {
            text-align: center;
            border-bottom: 2px solid #000000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        .invoice-header h1 {
            margin: 0;
            font-size: 2em;
        }

        .invoice-header address p {
            margin: 0;
            line-height: 1.5;
            font-size: 1em;
        }

        .invoice-info {
            margin-bottom: 20px;
        }

        .invoice-info p {
            margin: 5px 0;
            font-size: 1em;
        }

        .invoice-items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .invoice-items th, .invoice-items td {
            border: 1px solid #dddddd;
            padding: 8px;
            text-align: right;
            font-size: 1em;
        }

        .invoice-items th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .total-label {
            text-align: left;
        }

        .invoice-footer {
            text-align: center;
            border-top: 2px solid #000000;
            padding-top: 10px;
            margin-top: 20px;
        }

        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button-container a {
            text-decoration: none;
            color: #fff;    
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 10px 5px;
            display: inline-block;
            font-size: 1em;
        }

        .button-container a:hover {
            background-color: #0056b3;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .invoice-container {
                padding: 15px;
            }

            .invoice-header h1 {
                font-size: 1.5em;
            }

            .invoice-header address p {
                font-size: 0.9em;
            }

            .invoice-info p {
                font-size: 0.9em;
            }

            .invoice-items th, .invoice-items td {
                font-size: 0.9em;
                padding: 6px;
            }

            .button-container a {
                padding: 8px 16px;
                font-size: 0.9em;
            }
        }

        @media (max-width: 480px) {
            .invoice-container {
                width: 95%;
                padding: 10px;
            }

            .invoice-header h1 {
                font-size: 1.2em;
            }

            .invoice-header address p {
                font-size: 0.8em;
            }

            .invoice-info p {
                font-size: 0.8em;
            }

            .invoice-items th, .invoice-items td {
                font-size: 0.8em;
                padding: 5px;
            }

            .button-container a {
                padding: 6px 12px;
                font-size: 0.8em;
            }
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        <header class="invoice-header">
            <h1>Invoice</h1>
            <address>
                <p>AirWell</p>
                <p>Mumbai, Maharashtra</p>
                <p>Email: airwell@info.com</p>
                <p>Phone: (123) 456-7890</p>
            </address>
        </header>

        <?php
        
$in = "SELECT * FROM checkout INNER JOIN cart ON checkout.cart_id = cart.cart_id WHERE checkout.user_id='$uu_id'";
$IN_EX = mysqli_query($conn, $in);
$fetch_out = mysqli_fetch_assoc($IN_EX);
$sel_cart = "SELECT * FROM cart WHERE user_id='$uu_id'";
$result_fetch_product = mysqli_query($conn, $sel_cart);

?>
            
            <div id="content">
    <section class="invoice-info">
        <div class="invoice-date">
            <p><strong>Invoice Date:</strong> <?php echo $fetch_out['order_date']; ?></p>
        </div>
        <div class="invoice-details">
            <p><strong>Invoice Number:</strong> <?php echo $fetch_out['mobile_no']; ?></p>
            <p><strong>Customer Name:</strong> <?php echo $fetch_out['first_name'] . " " . $fetch_out['last_name']; ?></p>
        </div>
    </section>
    <section class="invoice-items">
        <table class="invoice-items">
            <thead>
                <tr>
                    <th class="total-label">Product</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Shipping</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
            <?php
            
            while($fetch_pro = mysqli_fetch_assoc($result_fetch_product)){ 
            ?>
                <tr>
                    <td><?= $fetch_pro['cart_name'] ?></td>
                    <td><?= $fetch_pro['cart_quantity'] ?></td>
                    <td><?= $fetch_pro['cart_price'] ?></td>
                    <td><?= 1000.00 ?></td>

                    <td><?= $fetch_pro['cart_total'] + 1000 ?></td>

                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
        
    </section>
    <section class="invoice-footer">
        <p>Thank you for your purchase!</p>
    </section>
</div>

<div class="button-container">
    <button id="download_Btn">Download</button>
    <a href="delete_cart.php">Back to Shop</a>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
<script>
    const download_button = document.getElementById('download_Btn');
    const content = document.getElementById('content');

    download_button.addEventListener('click', async function () {
        const filename = 'Bill.pdf'; 

        try {
            const opt = {
                margin: 1,
                filename: filename,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: {
                    unit: 'in',
                    format: 'letter',
                    orientation: 'portrait'
                }
            };
            await html2pdf().set(opt).from(content).save();
        } catch (error) {
            console.error('Error:', error.message);
        }
    });
</script>


        


</body>
</html>
