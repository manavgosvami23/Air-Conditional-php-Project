<?php
include("db.php");
include("header.php");

if(!isset($_SESSION['user_track'])) {
    header("Location: index.php");
}

$users_id = $_SESSION['user_track']['u_id'];
$fetch_cart = "SELECT * FROM cart WHERE user_id='$users_id'";
$cart_items = mysqli_query($conn, $fetch_cart);
$subtotal = 0;

$cart_data = [];

// Fetch cart items and calculate subtotal
while ($item = mysqli_fetch_array($cart_items)) {
    $item_total = $item['cart_price'] * $item['cart_quantity'];
    $subtotal += $item_total;

    $cart_data[] = [
        'id' => $item['pro_id'], // Add product ID to cart data
        'name' => $item['cart_name'],
        'price' => number_format($item['cart_price'], 2),
        'quantity' => $item['cart_quantity'],
        'total' => number_format($item_total, 2)
    ];
}

// Calculate total
$shipping = 1000;
$total = $subtotal + $shipping;
$_SESSION['last_orders_total'] = $total;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = [];

    // Server-side validation
    if (empty($_POST['first_name'])) {
        $errors[] = "First name is required.";
    }
    if (empty($_POST['last_name'])) {
        $errors[] = "Last name is required.";
    }
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required.";
    }
    if (empty($_POST['phone_num']) || !preg_match('/^[0-9]{10}$/', $_POST['phone_num'])) {
        $errors[] = "Valid 10-digit mobile number is required.";
    }
    if (empty($_POST['address_line1'])) {
        $errors[] = "Address is required.";
    }
    if (empty($_POST['city'])) {
        $errors[] = "City is required.";
    }
    if (empty($_POST['state'])) {
        $errors[] = "State is required.";
    }
    if (empty($_POST['zip_code']) || !preg_match('/^[0-9]{6}$/', $_POST['zip_code'])) {
        $errors[] = "Valid 6-digit ZIP code is required.";
    }
    if (empty($_POST['payment'])) {
        $errors[] = "Payment method is required.";
    }

    if (empty($errors)) {
        $fetch_cart = "SELECT * FROM cart WHERE user_id='$users_id'";
        $cart_items = mysqli_query($conn, $fetch_cart);
        $check = false;
        mysqli_begin_transaction($conn);

        try {
            // Process each cart item
            while ($cart_datas = mysqli_fetch_array($cart_items)) {
                $cart_id = $cart_datas['cart_id'];
                $p_id = $cart_datas['pro_id']; // Get product ID
                $check_price = $cart_datas['cart_price'];
                $check_quantity = $cart_datas['cart_quantity'];
                $first_name = $_POST['first_name'];
                $last_name = $_POST['last_name'];
                $email = $_POST['email'];
                $mobile_no = $_POST['phone_num'];
                $address_line1 = $_POST['address_line1'];
                $city = $_POST['city'];
                $state = $_POST['state'];
                $zip_code = $_POST['zip_code'];
                $payment_method = $_POST['payment'];

                // Insert checkout data
                $insert = "INSERT INTO checkout (user_id, cart_id,pro_id,first_name, last_name, email, mobile_no, address_line1, city, state, zip_code, check_price, check_quantity, payment_method)
                           VALUES ('$users_id', '$cart_id','$p_id','$first_name', '$last_name', '$email', '$mobile_no', '$address_line1', '$city', '$state', '$zip_code', '$check_price', '$check_quantity', '$payment_method')";
                $check = mysqli_query($conn, $insert);
                $sel_checkOut = "SELECT * FROM checkout WHERE user_id='$users_id' AND cart_id='$cart_id'";
                $sel_checkOut_Ex = mysqli_query($conn, $sel_checkOut);

                while ($check_fetch_data = mysqli_fetch_assoc($sel_checkOut_Ex)) {
                    $check_quan += $check_fetch_data['check_quantity'];
                }
                $_SESSION['last_orders'] = $check_quan;

                // Update stock in products table
                $update_stock = "UPDATE products SET stock = stock - '$check_quantity' WHERE id = '$p_id'";
                mysqli_query($conn, $update_stock);
            }

            if ($check) {
                mysqli_commit($conn);
            
                $_SESSION['validToOffer'] = true;
                echo "<script>alert('Order placed successfully');</script>";
                header("location:payment_success.php");
            }
             else {
                throw new Exception("Failed to insert checkout data.");
            }
        } catch (Exception $e) {
            mysqli_rollback($conn);
            echo "<script>alert('Something went wrong:');</script>";
        }
    } else {
        foreach ($errors as $error) {
            echo "<script>alert('$error');</script>";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Checkout Page</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Checkout Page" name="description">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- JavaScript form validation -->
    <script>
        function validateForm() {
            let errors = [];

            let firstName = document.forms["checkoutForm"]["first_name"].value;
            if (firstName === "") {
                errors.push("First name is required.");
            }

            let lastName = document.forms["checkoutForm"]["last_name"].value;
            if (lastName === "") {
                errors.push("Last name is required.");
            }

            let email = document.forms["checkoutForm"]["email"].value;
            let emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (email === "" || !emailPattern.test(email)) {
                errors.push("Valid email is required.");
            }

            let phoneNum = document.forms["checkoutForm"]["phone_num"].value;
            if (phoneNum === "" || !/^[0-9]{10}$/.test(phoneNum)) {
                errors.push("Valid 10-digit mobile number is required.");
            }

            let addressLine1 = document.forms["checkoutForm"]["address_line1"].value;
            if (addressLine1 === "") {
                errors.push("Address is required.");
            }

            let city = document.forms["checkoutForm"]["city"].value;
            if (city === "") {
                errors.push("City is required.");
            }

            let state = document.forms["checkoutForm"]["state"].value;
            if (state === "") {
                errors.push("State is required.");
            }

            let zipCode = document.forms["checkoutForm"]["zip_code"].value;
            if (zipCode === "" || !/^[0-9]{6}$/.test(zipCode)) {
                errors.push("Valid 6-digit ZIP code is required.");
            }

            let payment = document.forms["checkoutForm"]["payment"].value;
            if (payment === "") {
                errors.push("Payment method is required.");
            }

            if (errors.length > 0) {
                alert(errors.join("\n"));
                return false;
            }

            return true;
        }
    </script>
</head>

<body>
    <!-- Checkout Start -->
    <div class="container-fluid">
        <form name="checkoutForm" action="" method="POST" onsubmit="return validateForm();">
            <div class="row px-xl-5">
                <div class="col-lg-8">
                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Billing Address</span></h5>
                    <div class="bg-light p-30 mb-5">
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>First Name</label>
                                <input class="form-control" type="text" name="first_name">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Last Name</label>
                                <input class="form-control" type="text" name="last_name">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>E-mail</label>
                                <input class="form-control" type="email" name="email">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Mobile No</label>
                                <input class="form-control" type="text" name="phone_num">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Address Line 1</label>
                                <input class="form-control" type="text" name="address_line1">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>City</label>
                                <input class="form-control" type="text" name="city">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>State</label>
                                <input class="form-control" type="text" name="state">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>ZIP Code</label>
                                <input class="form-control" type="text" name="zip_code">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Order Total</span></h5>
                    <div class="bg-light p-30 mb-5">
                        <div class="border-bottom">
                            <h6 class="mb-3">Products</h6>
                            <?php foreach ($cart_data as $data): ?>
                                <div class="d-flex justify-content-between">
                                    <p><?php echo htmlspecialchars($data['name']); ?> (x<?php echo htmlspecialchars($data['quantity']); ?>)</p>
                                    <p>₹<?php echo htmlspecialchars($data['total']); ?></p>

                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="border-bottom pt-3 pb-2">
                            <div class="d-flex justify-content-between mb-3">
                                <h6>Subtotal</h6>
                                <h6>₹<?php echo number_format($subtotal, 2); ?></h6>
                            </div>
                            <div class="d-flex justify-content-between">
                                <h6 class="font-weight-medium">Shipping</h6>
                                <h6 class="font-weight-medium">₹<?php echo number_format($shipping, 2); ?></h6>
                            </div>
                        </div>
                        <?php
                                // wallet Textbox
                                $user_id = $_SESSION['user_track']['u_id']; 
                                $query = "SELECT * from wallet WHERE user_id = $user_id";
                                $result = mysqli_query($conn, $query);
                                $row = mysqli_fetch_assoc($result);
                                $wallet_amount = $row['discount'];



                        ?>

<div class="pt-2">
    <div class="d-flex justify-content-between mt-2">
        <h5>Total</h5>
        <h5>₹<?php echo number_format($total, 2); ?></h5><br>
    </div>

    <!-- Display wallet amount -->
    <div class="mt-2">
        <p>Do you want to use wallet?<br> Your wallet balance is: ₹<?php echo number_format($wallet_amount, 2); ?></p>
        <input type="text" class="form-control" placeholder="Enter value" />
    </div>
</div>

                    </div>
                    <div class="mb-5">
                        <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Payment</span></h5>
                        <div class="bg-light p-30">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input type="radio" class="custom-control-input" name="payment" id="paypal" value="credit card">
                                    <label class="custom-control-label" for="paypal">Credit Card</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input type="radio" class="custom-control-input" name="payment" id="directcheck" value="debit card">
                                    <label class="custom-control-label" for="directcheck">Debit Card</label>
                                </div>
                            </div>
                            <div class="form-group mb-4">
                                <div class="custom-control custom-radio">
                                    <input type="radio" class="custom-control-input" name="payment" id="banktransfer" value="banktransfer">
                                    <label class="custom-control-label" for="banktransfer">Bank Transfer</label>
                                </div>
                            </div>

                            <button class="btn btn-block btn-primary font-weight-bold py-3" type="submit" name="place">Checkout</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- Checkout End -->
</body>
<?php include("footer.php"); ?>

</html>