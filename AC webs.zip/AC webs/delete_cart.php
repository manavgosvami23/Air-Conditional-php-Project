<?php
session_start();

include("db.php");

$uu_id = $_SESSION['user_track']['u_id'];
$delete_cart = "DELETE FROM cart WHERE user_id='$uu_id'";
       $q= mysqli_query($conn, $delete_cart);
       if($q)
       {

        header("Location:shop.php");
       }
       else{
        echo "not delete";
       }

?>