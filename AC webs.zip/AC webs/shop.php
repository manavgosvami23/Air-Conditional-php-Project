<?php
include("header.php");
?>
<style>
    .banner {
        position: relative;
        width: 100%;
        height: 300px;
        overflow: hidden;
    }

    .banner-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        filter: grayscale(50%) brightness(70%);
    }

    .banner-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
        font-size: 3em;
        font-weight: bold;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }
</style>

<div class="banner">
    <img src="banar.jpg" alt="AirWell Banner" class="banner-image">
    <h1 class="banner-text">Shop</h1>
</div>
 <!-- ========== Start New Items products ========== -->
 <section class="new-ac-section">
    <div class="container">
      <h2 class="section_title">New arrivals</h2>
      <div class="product-container">
        <?php
        $fetch_product = "SELECT * FROM products";
        $fetch_product_Ex = mysqli_query($conn,$fetch_product);
        while($data = mysqli_fetch_array($fetch_product_Ex)){
          ?>
            <div class="pro_card">
          <div class="ac_img">
            <img src="uploads/<?php echo $data['image']; ?>" alt="ac items" height="200hv" width="auto"/>
          </div>
          <div class="ac_title">
            <h3><?php echo $data['name']?></h3>
          </div>
          <div class="ac_config">
            <span>1.5 Ton</span>
            <span>5-Star</span>
          </div>
          <div class="ac_price">
            <p><?php echo $data['price']?></p>
          </div>
          <div class="ac_button">
            <a href="detail.php?id=<?php echo $data['id']; ?>" class="commn-btn">Buy Now</a>
          </div>
        </div>
          <?php
        }

        ?>
      
      </div>
    </div>
  </section>
<?php
include("footer.php");
?>
</body>

</html>