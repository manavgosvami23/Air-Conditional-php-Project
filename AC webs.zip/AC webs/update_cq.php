<?php
include("db.php");

if (isset($_POST['up_cq']) && isset($_POST['up_cid'])) {
    $quantity = intval($_POST['up_cq']);
    $cart_id = intval($_POST['up_cid']);

    $update_query = "UPDATE cart SET cart_quantity='$quantity' WHERE cart_id='$cart_id'";
    if (mysqli_query($conn, $update_query)) {
        echo "Quantity updated successfully";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

?>
