<?php
include("db.php");

if (isset($_POST['sendUserId'])) {
  $user_id = $_POST['sendUserId'];

  $qty = 0;

  $fetch_cart_data = "SELECT * FROM cart INNER JOIN products ON cart.pro_id=products.id WHERE user_id='$user_id'";
  $fetch_cart_data_Ex = mysqli_query($conn, $fetch_cart_data);
  $subtotal = 0;
  while ($dataCart = mysqli_fetch_array($fetch_cart_data_Ex)) {
    $item_total = $dataCart['cart_price'] * $dataCart['cart_quantity'];
    $subtotal += $item_total;

?>
    <tr data-id="<?php echo $dataCart['cart_id']; ?>">
      <td class="align-middle"><img src="<?php echo $dataCart['cart_image']; ?>" alt="" style="width: 50px;"></td>
      <td class="align-middle"><?php echo $dataCart['cart_name']; ?></td>
      <td class="align-middle">₹<?php echo number_format($dataCart['cart_price'], 2); ?></td>
      <td class="align-middle">
        <div class="input-group quantity mx-auto" style="width: 100px;">
          <div class="input-group-btn">
            <button class="btn btn-sm btn-primary btn-minus">
              <i class="fa fa-minus"></i>
            </button>
          </div>
          <input type="text" class="form-control form-control-sm bg-secondary border-0 text-center quantity-input" value="<?php echo $dataCart['cart_quantity']; ?>">
          <div class="input-group-btn">
             <button class="btn btn-sm btn-primary btn-plus" <?php if($dataCart['stock'] == $dataCart['cart_quantity']){
                  echo "disabled";
                } ?>>
              <i class="fa fa-plus"></i>
            </button>
          </div>
        </div>
      </td>
      <td class="align-middle item-total">₹<?php echo number_format($item_total, 2); ?></td>
      <td class="align-middle"><button class="btn btn-sm btn-danger btn-remove" data-value="<?php echo $dataCart['cart_id']; ?>"><i class="fa fa-times"></i></button></td>
    </tr>

<?php
  }
}

?>