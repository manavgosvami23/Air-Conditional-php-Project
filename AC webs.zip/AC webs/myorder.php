<?php
include("db.php");
include("header.php");

$users_id = $_SESSION['user_track']['u_id'];


//  order cancellation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancel_order'])) {
    $order_id = $_POST['order_id'];

    mysqli_begin_transaction($conn);

    try {
        // Fetch the order details
        $fetch_order = "SELECT * FROM checkout WHERE user_id='$users_id' AND cart_id='$order_id'";
        $order_result = mysqli_query($conn, $fetch_order);

        if ($order = mysqli_fetch_array($order_result)) {
            $check_quantity = $order['check_quantity'];
            $p_id = $order['pro_id'];

            // Restore stock in the products table
            $update_stock = "UPDATE products SET stock = stock + '$check_quantity' WHERE id = '$p_id'";
            if (!mysqli_query($conn, $update_stock)) {
                throw new Exception("Failed to update stock: " . mysqli_error($conn));
            }

            // Delete the order from the checkout table
            $delete_order = "DELETE FROM checkout WHERE user_id='$users_id' AND cart_id='$order_id'";
            if (!mysqli_query($conn, $delete_order)) {
                throw new Exception("Failed to delete order: " . mysqli_error($conn));
            }

            mysqli_commit($conn);
            echo "<script>alert('Order cancelled successfully');</script>";
            header("Refresh:0");
            exit; 
        } else {
            throw new Exception("Order not found.");
        }
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo "<script>alert('Something went wrong:');</script>";
    }
}




// Fetch orders for the user
$fetch_orders = "SELECT * FROM checkout WHERE user_id='$users_id'";
$orders = mysqli_query($conn, $fetch_orders);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>My Orders</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="My Orders Page" name="description">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!-- Orders Start -->
    <div class="container-fluid">
        <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">My Orders</span></h5>
        <div class="bg-light p-30 mb-5">
            <?php if (mysqli_num_rows($orders) > 0): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php while ($order = mysqli_fetch_array($orders)): ?>
                            <?php
                            $sel_pro="select * from products where id='".$order['pro_id']."'";
                            $sel_pro_ans =mysqli_query($conn,$sel_pro);
                            $fp=mysqli_fetch_array($sel_pro_ans);
                            $cart_name = $fp['name'];
                            $check_price = floatval($order['check_price'] ?? 0);
                            $check_quantity = intval($order['check_quantity'] ?? 0);
                            $total = $check_price * $check_quantity;
                            ?>
                            <tr>
                                <td><?php echo $cart_name; ?></td>
                                <td>₹<?php echo number_format($check_price, 2); ?></td>
                                <td><?php echo $check_quantity; ?></td>
                                <td>₹<?php echo number_format($total, 2); ?></td>
                                <td><?php echo htmlspecialchars($order['status'] ?? 'Pending'); ?></td>
                                <td>
                                    <form method="POST" action="">
                                        <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order['cart_id']); ?>">
                                        <button type="submit" name="cancel_order" class="btn btn-danger">Cancel Order</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No orders found.</p>
            <?php endif; ?>
        </div>
    </div>
    <!-- Orders End -->
</body>
<?php include("footer.php"); ?>

</html>
