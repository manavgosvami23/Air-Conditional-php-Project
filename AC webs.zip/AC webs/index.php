<?php
include("header.php");
include("db.php");

?>
<main>
  <section class="hero_section">
    <div class="container set_hero">
      <div class="content order-1">
        <p class="slog">Stay Cool, Live Comfortably</p>
        <h1>
          "GUARANTEED 5% UP TO 50% DISCOUNT ON PRODUCTS"<h2><a href="discount_details.php">LEARN MORE</a></h2><br>
          
        </h1>
        <H2>AC <span>AirWell</span></H2><BR>
        <p>
          Local AC professionals committed to your comfort <br />
          satisfaction.
        </p>
        <button class="hero_btn">Stay Cool</button>
      </div>
      <div class="hero_images order-2">
        <img src="hero_section/ac_landing.svg" alt="" />
      </div>
    </div>
  </section>
  <!-- ========== Start New Items products ========== -->
  <section class="new-ac-section">
    <div class="container">
      <h2 class="section_title">New arrivals</h2>
      <div class="product-container">
        <?php
        $fetch_product = "SELECT * FROM products";
        $fetch_product_Ex = mysqli_query($conn,$fetch_product);
        while($data = mysqli_fetch_array($fetch_product_Ex)){
          ?>
            <div class="pro_card">
          <div class="ac_img">
            <img src="uploads/<?php echo $data['image']; ?>" alt="ac items" height="200hv" width="auto"/>
          </div>
          <div class="ac_title">
            <h3><?php echo $data['name']?></h3>
          </div>
          <div class="ac_config">
            <span>1.5 Ton</span>
            <span>5-Star</span>
          </div>
          <div class="ac_price">
            <p><?php echo $data['price']?></p>
          </div>
          <div class="ac_button">
            <a href="detail.php?id=<?php echo $data['id']; ?>" class="commn-btn">Buy Now</a>
          </div>
        </div>
          <?php
        }

      ?>
       




      
      
      </div>
    </div>
  </section>
  <!-- ========== End New Items products ========== -->
</main>


<?php
include("footer.php");
?>
</body>

</html>