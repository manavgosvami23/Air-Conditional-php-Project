    <?php
    include("db.php");
    include("header.php");

    if(!isset($_SESSION['user_track'])) {
      header("Location: index.php");
  }
  $users_id = $_SESSION['user_track']['u_id'];

 
  
    $fetch_cart = "SELECT * FROM cart WHERE user_id='$users_id'";
    $cart_items = mysqli_query($conn, $fetch_cart);

    $subtotal = 0; // Initialize subtotal
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
      <meta charset="utf-8">
      <title>Shopping Cart</title>
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
      <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>


    </head>

    <body>

      
                <?php
            

                if ($row_count > 0) {
                  // header("location:checkout.php");
                ?>
                <!-- Cart Start -->
      <div class="container-fluid">
        <div style="height : 16px;"></div>
        <div class="row justify-content-space-between p-5">
          <div class="col-lg-8 table-responsive">
            <table class="table table-light table-borderless table-hover text-center mb-0">
              <thead class="thead-dark">
                <tr>
                  <th>Image</th>
                  <th>Product Name</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total</th>
                  <th>Remove</th>
                </tr>
              </thead>
              <tbody class="align-middle">

              </tbody>
            </table>
          </div>
          
          <a href="checkout.php" style="color:white; text-decoration:none;"></a>
          <div class="col-lg-4">
            <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Cart Summary</span></h5>
            <div class="bg-light p-30 mb-5">
              <div class="border-bottom pb-2">
                <div class="d-flex justify-content-between mb-3">
                  <h6>Subtotal</h6>
                  <h6 id="cart-subtotal">₹<?php echo number_format($subtotal, 2); ?></h6>
                </div>
                <div class="d-flex justify-content-between">
                  <h6 class="font-weight-medium">Shipping</h6>
                  <h6 class="font-weight-medium">₹1000</h6>
                </div>
              </div>
              <div class="pt-2">
                <div class="d-flex justify-content-between mt-2">
                  <h5>Total</h5>
                  <h5 id="cart-total">₹<?php echo number_format($subtotal + 1000, 2); ?></h5>
                </div>
                  <a href="checkout.php" name="process" class="btn btn-block btn-primary font-weight-bold my-3 py-3">Proceed To Checkout</a>
                <?php
                } else {
                ?>
                  <img src="cart_empty.webp" alt="" height="400px" width="40%" style="position:relative; left:30%; top:100px;">
                <?php
                }
                ?>


              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Cart End -->
      <script>
        $(document).ready(function() {

          // Function to load cart data
          function loadcartdata() {
            $.ajax({
              url: "fetchcartData.php",
              type: "POST",
              data: {
                sendUserId: <?php echo $users_id; ?>
              },
              success: function(response) {
                $(".align-middle").html(response);
                updateCartTotals(); // Update the cart totals after loading data
              }
            });
          }

          // Function to update cart totals
          function updateCartTotals() {
            let subtotal = 0;
            $('.item-total').each(function() {
              subtotal += parseFloat($(this).text().replace('₹', '').replace(',', ''));
            });
            $('#cart-subtotal').text('₹' + subtotal.toFixed(2));
            $('#cart-total').text('₹' + (subtotal + 1000).toFixed(2));
          }

          // Function to update cart quantity in the database
          function updateCartQuantity(quantity, itemId) {
            $.ajax({
              url: "update_cq.php",
              type: "POST",
              data: {
                up_cq: quantity,
                up_cid: itemId
              },
              success: function(response) {
                console.log('Server Response:', response);
                loadcartdata(); // Reload cart data after update
              },
              error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
              }
            });
          }

          // Increase quantity
          $(document).on("click", ".btn-plus", function() {
            let row = $(this).closest('tr');
            let quantityInput = row.find('.quantity-input');
            let itemId = row.data('id');
            let newQuantity = parseInt(quantityInput.val()) + 1;
            // if (newQuantity > 20) {
            //   newQuantity = 20;
            // }
            quantityInput.val(newQuantity);
            let price = parseFloat(row.find('td:nth-child(3)').text().replace('₹', '').replace(',', ''));
            let newTotal = price * newQuantity;
            row.find('.item-total').text('₹' + newTotal.toFixed(2));
            updateCartQuantity(newQuantity, itemId);
          });

          // Decrease quantity
          $(document).on("click", ".btn-minus", function() {
            let row = $(this).closest('tr');
            let quantityInput = row.find('.quantity-input');
            let itemId = row.data('id');
            let newQuantity = parseInt(quantityInput.val()) - 1;
            if (newQuantity < 1) return;
            quantityInput.val(newQuantity);
            let price = parseFloat(row.find('td:nth-child(3)').text().replace('₹', '').replace(',', ''));
            let newTotal = price * newQuantity;
            row.find('.item-total').text('₹' + newTotal.toFixed(2));
            updateCartQuantity(newQuantity, itemId);
          });

          // Remove item from cart
          $(document).on("click", ".btn-remove", function() {
            let del_id = $(this).data("value");
            console.log("Remove button clicked. Item ID:", del_id); // Debugging line

            $.ajax({
              url: "remove_item.php",
              type: "POST",
              data: {
                del_ids: del_id
              },
              success: function(response) {
                console.log("Server Response:", response); // Debugging line
                loadcartdata(); // Reload cart data after removal
              },
              error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error); // Debugging line
              }
            });
          });


          // Initial load of cart data
          loadcartdata();

        });
      </script>


    </body>
    <?php include("footer.php") ?>

    </html>