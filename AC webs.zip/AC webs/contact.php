<?php
include("header.php");


?>
<?php
    
    
    if(isset($_POST['sub']))
    {
        $u_id = $_SESSION['user_track']['u_id'];
        $um = $_POST['username'];
        $uemail = $_POST['email'];
        $us = $_POST['subject'];
        $umsg = $_POST['msg'];

        $insert_feed = "insert into feedback (u_id,u_name,email,subject,message) values ('$u_id','$um','$uemail','$us','$umsg')";
        $insert_feed_ex = mysqli_query($conn,$insert_feed);
        if($insert_feed_ex){
            
            header("location:index.php");
        }
        else if(!$u_id){
            header("location:login.php");
        }
        else{
            echo "<script>sorry!</script>";
        }
    }
?>
<style>
    .banner {
        position: relative;
        width: 100%;
        height: 300px;
        overflow: hidden;
    }

    .banner-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        filter: brightness(70%);
    }

    .banner-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
        font-size: 3em;
        font-weight: bold;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }

    .contact-container {
        max-width: 600px;
        margin: 40px auto;
        padding: 20px;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .contact-form {
        display: flex;
        flex-direction: column;
    }

    .form-group {
        margin-bottom: 20px;
    }

    input,
    textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 16px;
    }

    textarea {
        height: 150px;
        resize: vertical;
    }

    .submit-btn {
        background-color: #3498db;
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.3s ease;
    }

    .submit-btn:hover {
        background-color: #2980b9;
    }

    @media (max-width: 768px) {
        .banner-text {
            font-size: 2em;
        }

        .contact-container {
            margin: 20px;
        }
    }
</style>
<div class="banner">
    <img src="banar.jpg" alt="Contact Us Banner" class="banner-image">
    <h1 class="banner-text">Contact Us</h1>
</div>

<div class="contact-container">
    <form  method="post" class="contact-form">
        <div class="form-group">
            <input type="text" name="username" placeholder="Enter name" required>
        </div>
        <div class="form-group">
            <input type="email" name="email" placeholder="Enter email" required>
        </div>
        <div class="form-group">
            <input type="text" name="subject" placeholder="Enter subject" required>
        </div>
        <div class="form-group">
            <textarea name="msg" placeholder="Enter message" required></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="submit-btn" name="sub">Send</button>
        </div>
    </form>
</div>
<?php
include("footer.php");
?>

</body>

</html>