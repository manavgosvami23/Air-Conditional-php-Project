<footer class="footer">
  <div class="footer-content">
    <div class="footer-section">
      <h3>About Us</h3>
      <p>
        We're your trusted AC experts, providing quality cooling solutions
        for over 20 years.
      </p>
    </div>
    <div class="footer-section">
      <h3>Contact</h3>
      <p>Email: info@acshop.com</p>
      <p>Phone: (123) 456-7890</p>
      <p>Address: 123 Cool St, Chillville, AC 12345</p>
    </div>
    <div class="footer-section">
      <h3>Quick Links</h3>
      <p><a href="#">Services</a></p>
      <p><a href="#">Products</a></p>
      <p><a href="#">FAQs</a></p>
    </div>
    <div class="footer-section">
      <h3>Follow Us</h3>
      <ul class="social-icons">
        <li>
          <a href="#"><i class="fab fa-facebook"></i></a>
        </li>
        <li>
          <a href="#"><i class="fa-brands fa-x-twitter"></i></a>
        </li>
        <li>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </li>
      </ul>
    </div>
  </div>
  <div class="copyright">
    <p>&copy; 2024 AC Shop. All rights reserved.</p>
  </div>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>