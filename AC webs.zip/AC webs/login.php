<?php
 include('db.php');
    session_start();
   

    if($_SERVER['REQUEST_METHOD']=="POST")
    {
    $email=$_POST['em'];
    $ps=$_POST['pass'];

    if(!empty($email) && !empty($ps) && !is_numeric($email))
    {
        $q="select * from register where email='$email' limit 1";
        $result=mysqli_query($conn,$q);

        if($result)
        {
            if($result && mysqli_num_rows($result)>0)
            {
                $userdata=mysqli_fetch_array($result);
                $_SESSION['user_track'] =  $userdata;
                if($userdata['password']==$ps)
                {
                    header("location:index.php");
                    die;
                }
            }
            echo "<script> alert('wrong username and password') </script>";

        }
        else{
        echo "<script> alert('wrong username and password') </script>";
        }
    }
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="login.css">

    <title>Login Page</title>
</head>
<body>
    <div class="wrapper">
        <form action="" method="post">
            <h1>Login</h1>
            <div class="input">
                <input type="email" placeholder="email" name="em" required>
            </div>
            <div class="input">
                <input type="password" placeholder="password" name="pass" required>
            </div>
            <div class="forget">
               <label><input type="checkbox">Remember me</label>
               <a href="#">Forget password</a>
            </div>
            <button type="submit" class="btn" name="sub">Login</button>
            <div class="register">
                <P>Don`t have an account?<a href="register.php">Register</a></P>
            </div>
        </form>
    </div>
</body>
</html>