<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful Animation</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #D4EDDA;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .container {
            text-align: center;
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .checkmark {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 5px solid #4caf50;
            position: relative;
            display: inline-block;
            background: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            animation: scaleUp 0.3s ease-in-out forwards;
        }
        .checkmark:before {
            content: '';
            width: 10px;
            height: 50px;
            border-right: 5px solid #4caf50;
            border-bottom: 5px solid #4caf50;
            position: absolute;
            top: 10px; /* Adjusted for vertical centering */
            left: 50px; /* Adjusted for horizontal centering */
            transform: rotate(45deg);
            transform-origin: left top;
            animation: drawCheck 0.5s ease-in-out 0.3s forwards;
        }
        @keyframes scaleUp {
            from {
                transform: scale(0);
            }
            to {
                transform: scale(1);
            }
        }
        @keyframes drawCheck {
            from {
                width: 0;
                height: 0;
            }
            to {
                width: 10px;
                height: 50px;
            }
        }
        .message {
            font-size: 20px;
            color: #4caf50;
            opacity: 0;
            margin-top: 20px;
            animation: fadeIn 0.5s ease-in-out 0.8s forwards;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        .reward-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #4caf50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            opacity: 0;
            transform: scale(0.9);
            animation: fadeInButton 0.5s ease-in-out 1.3s forwards;
        }
        @keyframes fadeInButton {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="checkmark"></div>
        <div class="message">Payment Successful</div>
        <a href="./spinner/index.php" class="reward-button">Claim Reward</a>
    </div>
</body>
</html>
