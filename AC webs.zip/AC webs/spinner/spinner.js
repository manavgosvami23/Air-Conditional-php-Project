const spinButton = document.querySelector(".spin");
const spinnerCon = document.querySelector(".spinner");
const descount = document.querySelectorAll(".descount");
const win_content = document.querySelector("#win_content");

let user_result = null;
let last_total = null;
let shouldBlockNewTab = true; 
spinButton.disabled = true; 

function handleSpin() {
  spinButton.remove();
  spinnerCon.style.animationName = "spin";
  let result = null;

  setTimeout(() => {
    if (user_result === 5) {
      result = callHakingFive();
    } else if (user_result === 8) {
      result = callHakingEight();
    }

    descount.forEach((item) => {
      let attributeValue = item.getAttribute("winnerChoice");
      if (parseInt(attributeValue) === result) {
        item.classList.add("winner");
      }
    });

    win_content.textContent = `Congratulations, you won ${result}% discount`;
    spinnerCon.style.animationName = "";

    updateWallet(result);
  }, 3000);
}

function randomIndex(length) {
  return Math.floor(Math.random() * length);
}

const callHakingFive = () => {
  const discount = [5];
  return discount[randomIndex(discount.length)];
}

const callHakingEight = () => {
  const discount = [8];
  return discount[randomIndex(discount.length)];
}

// fetch discount data
$(document).ready(function () {
  function load_data() {
    let user_id = $("#user_id").val();
    $.ajax({
      url: "fetch_cart.php",
      type: "POST",
      data: { user_id: user_id },
      success: function (res) {
        const data = JSON.parse(res);
        console.log(data);
        const discount = data.discount;
        last_total = data.last_orders_total;
        user_result = discount;
        spinButton.disabled = false; // Enable the spin button here
      }
    });
  }

  load_data();
});

// update wallet
function updateWallet(discount) {
  let user_id = $("#user_id").val();
  $.ajax({
    url: "wallet_update.php",
    type: "POST",
    data: { user_id: user_id, discount: discount, totals: last_total },
    success: function (response) {
      alert(`CONGRATULATIONS! YOU WON : ${discount}% DISCOUNT`);
      
      if (shouldBlockNewTab) {
        window.location.href = "http://localhost:81/AC%20webs/bill.php";
      } else {
        window.open("#");
      }
      
      console.log(response);
    },
    error: function (xhr, status, error) {
      console.error("Failed to update wallet: ", error);
    }
  });
}

// block prevent page
window.history.forward();
function noBack() {
  window.history.forward();
}

spinButton.addEventListener("click", handleSpin);
