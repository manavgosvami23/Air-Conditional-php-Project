<?php
session_start();
include('../db.php');

if (isset($_POST['user_id']) && isset($_POST['discount'])) {
    $user_id = $_POST['user_id'];
    $discount = $_POST['discount'];
    $lastTotals = $_POST['totals'];
    $finalWallet = ($lastTotals * $discount) / 100;

    $check_wallet_query = "SELECT * FROM wallet WHERE user_id = $user_id";
    $check_wallet_result = mysqli_query($conn, $check_wallet_query);
    $fetch_old_wallet = mysqli_fetch_assoc($check_wallet_result);
    $finalWallet += $fetch_old_wallet['discount'];
    if (mysqli_num_rows($check_wallet_result) > 0) {
        // Update wallet
        $update_wallet_query = "UPDATE wallet SET discount = '$finalWallet' WHERE user_id = $user_id";
        mysqli_query($conn, $update_wallet_query);
    } else {
        $insert_wallet_query = "INSERT INTO wallet (user_id, discount) VALUES ('$user_id', '$finalWallet')";
        mysqli_query($conn, $insert_wallet_query);
    }

} else {
    echo "Invalid request";
}
