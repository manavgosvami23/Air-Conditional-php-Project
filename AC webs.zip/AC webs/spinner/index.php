<?php
include("../db.php");
session_start();

if(isset($_SESSION['validToOffer'])){
$user_id = $_SESSION['user_track']['u_id'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>
  <link rel="stylesheet" href="style.css" />
</head>

<body>
<body onLoad="noBack();" onpageshow="if (event.persisted) noBack();" onUnload="">

  <div class="container">
    <div class="spinner">
      <div class="descount" winnerChoice="0" id="zero">0%</div>
      <div class="descount" winnerChoice="5" id="five">5%</div>
      <div class="descount" winnerChoice="8" id="eight">8%</div>
      <div class="descount" winnerChoice="10" id="ten">10%</div>
      <div class="descount" winnerChoice="20" id="twenty">20%</div>
      <div class="descount" winnerChoice="30" id="thrty">30%</div>
      <div class="descount" winnerChoice="40" id="fourty">40%</div>
      <div class="descount" winnerChoice="50" id="fifty">50%</div>
      <button id="center" class="spin">Spin</button>
    </div>
    <h1 id="win_content"></h1>
    <input type="hidden" id="user_id" value="<?= $user_id; ?>">
  </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="spinner.js"></script>

</html>
<?php
unset($_SESSION['validToOffer']);
} else {
  echo "<h1>404</h1>";
}

?>