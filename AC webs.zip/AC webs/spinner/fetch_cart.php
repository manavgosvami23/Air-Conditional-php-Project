<?php
include("../db.php");
session_start();

// Assuming these are the values you want to send back
$last_orders_total = $_SESSION['last_orders_total'];
$discount = ($_SESSION['last_orders'] == 1) ? 5 : 8;

// Prepare the data as an associative array
$response = array(
  "last_orders_total" => $last_orders_total,
  "discount" => $discount
);

// Encode the array as a JSON object and output it
echo json_encode($response);
