<?php
include('db.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $fn = trim($_POST['firstname']);
    $ln = trim($_POST['lastname']);
    $un = trim($_POST['username']);
    $gm = trim($_POST['email']);
    $pass = trim($_POST['password']);

    // Server-side validation
    $errors = [];

    if (empty($fn)) {
        $errors[] = "First name is required.";
    }
    if (empty($ln)) {
        $errors[] = "Last name is required.";
    }
    if (empty($un)) {
        $errors[] = "Username is required.";
    }
    if (empty($gm) || !filter_var($gm, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required.";
    }
    if (empty($pass) || !preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $pass)) {
        $errors[] = "Password must be at least 8 characters long, contain uppercase and lowercase letters, a number, and a special character.";
    }

    if (empty($errors)) {
        $query = "INSERT INTO register (firstname, lastname, username, email, password) VALUES ('$fn', '$ln', '$un', '$gm', '$pass')";
        if (mysqli_query($conn, $query)) {
            echo "<script> alert('Registration successful!'); </script>";
            header("location:login.php");
            exit();
        } else {
            echo "<script> alert('Registration failed. Please try again.'); </script>";
        }
    } else {
        foreach ($errors as $error) {
            echo "<script> alert('$error'); </script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <link rel="stylesheet" href="register.css">
    <script>
        function validateForm() {
            let firstName = document.forms["registerForm"]["firstname"].value.trim();
            let lastName = document.forms["registerForm"]["lastname"].value.trim();
            let userName = document.forms["registerForm"]["username"].value.trim();
            let email = document.forms["registerForm"]["email"].value.trim();
            let password = document.forms["registerForm"]["password"].value.trim();
            let errors = [];

            if (firstName === "") {
                errors.push("First name is required.");
            }
            if (lastName === "") {
                errors.push("Last name is required.");
            }
            if (userName === "") {
                errors.push("Username is required.");
            }
            let emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (email === "" || !emailPattern.test(email)) {
                errors.push("Valid email is required.");
            }

            // Enhanced password validation (at least 8 chars, uppercase, lowercase, number, special char)
            let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            if (password === "" || !passwordPattern.test(password)) {
                errors.push("Password must be at least 8 characters long, contain uppercase and lowercase letters, a number, and a special character.");
            }

            if (errors.length > 0) {
                alert(errors.join("\n"));
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="wrapper">
        <form name="registerForm" action="" method="post" onsubmit="return validateForm();">
            <h1>Register</h1>
            <div class="input">
                <input type="text" placeholder="First name" name="firstname" required>
            </div>
            <div class="input">
                <input type="text" placeholder="Last name" name="lastname" required>
            </div>
            <div class="input">
                <input type="text" placeholder="Username" name="username" required>
            </div>
            <div class="input">
                <input type="email" placeholder="Email" name="email" required>
            </div>
            <div class="input">
                <input type="password" placeholder="Password" name="password" required>
            </div>
            <div class="reg">
                <button type="submit" class="btn" name="sub">Sign Up</button>
            </div>
        </form>
    </div>
</body>
</html>
